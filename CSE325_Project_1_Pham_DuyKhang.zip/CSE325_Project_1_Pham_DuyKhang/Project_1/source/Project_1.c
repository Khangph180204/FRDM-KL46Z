#include "fsl_device_registers.h"
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"

// Custom function to create a simple time delay
void simple_delay(unsigned int time) {
    volatile unsigned int x, y;
    for(x = 0; x < time; x++) {
        for(y = 0; y < 1000; y++) {
            __asm("nop");  // No operation, just delay
        }
    }
}

int main(void) {
    // Enable clock access for GPIO ports (PTE, PTD, PTA)
    SIM->SCGC5 |= (1 << 13) | (1 << 12) | (1 << 9);

    // --- Configure PTE29 as output for Red LED ---
    PORTE->PCR[29] = (PORTE->PCR[29] & ~0x700) | (1 << 8); // Set as GPIO
    GPIOE->PDDR |= (1 << 29);  // Set as output

    // --- Configure PTD5 as output for Green LED ---
    PORTD->PCR[5] = (PORTD->PCR[5] & ~0x700) | (1 << 8); // Set as GPIO
    GPIOD->PDDR |= (1 << 5);  // Set as output

    // --- Configure PTA12 as output for Yellow LED ---
    PORTA->PCR[12] = (PORTA->PCR[12] & ~0x700) | (1 << 8); // Set as GPIO
    GPIOA->PDDR |= (1 << 12);  // Set as output

    // --- Configure PTA1 as input for the switch ---
    PORTA->PCR[1] = (PORTA->PCR[1] & ~0x700) | (1 << 8); // Set as GPIO
    PORTA->PCR[1] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; // Enable pull-up resistor
    GPIOA->PDDR &= ~(1 << 1);  // Set as input

    // --- Ensure all LEDs are OFF initially ---
    GPIOE->PSOR = (1 << 29);   // Red OFF
    GPIOD->PSOR = (1 << 5);    // Green OFF
    GPIOA->PCOR = (1 << 12);   // Yellow OFF (Active HIGH)

    // --- Main program loop ---
    while (1) {
        if (GPIOA->PDIR & (1 << 1)) {  // If the button is NOT pressed
            // --- Turn ON Red LED ---
            GPIOE->PCOR = (1 << 29);   // Activate Red (Active LOW)
            GPIOD->PSOR = (1 << 5);    // Deactivate Green
            GPIOA->PCOR = (1 << 12);   // Deactivate Yellow
            simple_delay(5000);  // 5 sec delay

            // --- Turn ON Green LED ---
            GPIOE->PSOR = (1 << 29);   // Deactivate Red
            GPIOD->PCOR = (1 << 5);    // Activate Green (Active LOW)
            GPIOA->PCOR = (1 << 12);   // Ensure Yellow is OFF
            simple_delay(5000);  // 5 sec delay

            // --- Turn ON Yellow LED ---
            GPIOE->PSOR = (1 << 29);   // Deactivate Red
            GPIOD->PSOR = (1 << 5);    // Deactivate Green
            GPIOA->PSOR = (1 << 12);   // Activate Yellow (Active HIGH)
            simple_delay(5000);  // 5 sec delay
            GPIOA->PCOR = (1 << 12);   // Deactivate Yellow
            simple_delay(1000);  // 1 sec delay
        } else {  // If the button is pressed
            // --- Blink Yellow LED only ---
            GPIOA->PTOR = (1 << 12);    // Toggle Yellow LED
            simple_delay(500);  // 500ms delay
        }
    }

    return 0;  // This will never be reached due to infinite loop
}

