// motor_control.h
#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "fsl_device_registers.h"

// Constants
#define SAFE_DISTANCE_CM 8
#define LINE_THRESHOLD 200

// Motor Control
void motor_init(void);
void motor_forward(void);
void motor_stop(void);
void motor_set_speed(int duty);

//Soft Turning
void turn_left_soft(void);
void turn_right_soft(void);

// Timer (Delay)
void pit_timer_init(void);
void start_timer(int ms);
int check_timer(void);

// Button
void init_sw1(void);
int is_sw1_pressed(void);

// SW2
void init_sw2(void);
int is_sw2_pressed(void);

//Line Sensors
void init_line_sensor(void);
int read_line_sensor_left(void);
int read_line_sensor_right(void);

//Servo Control
void init_servo(void);
void set_servo_angle(int angle);
void servo_center(void);
void servo_left(void);
void servo_right(void);

//Ultrasonic Sensor
void init_ultrasonic(void);
void trigger_pulse(void);
int measure_distance_cm(void);

//Color Sensor
void init_color_sensor(void);
int detect_color_id(void);

#endif
