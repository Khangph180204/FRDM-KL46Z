#include "motor_control.h"
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"

#define Left_THRESHOLD 2000
#define Right_THRESHOLD 2000
#define LINE_THRESHOLD 200

void delay(int ms) {
    start_timer(ms);
    while (!check_timer());
}

// Simple state tracking
int green_zone_counter = 0;

int main(void) {
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();

    motor_init();
    init_line_sensor();
    init_sw1();

    PRINTF("Robot Ready. Press SW1 to start moving from any zones...\n");

    while (!is_sw1_pressed());
    delay(300);

    PRINTF("Running initial custom path...\n");

    // -------------------Path 1 and path 4-------------------------
    //motor_forward();
    //delay(1000);
    //motor_stop();
    //delay(1000);
    //turn_right_soft();
    //delay(1300);
    //motor_stop();
    //delay(1000);
    //motor_forward();
    //delay(2000);
    //motor_stop();
    //delay(1000);
    //turn_left_soft();
    //delay(600);
    //motor_stop();
    //delay(1000);
    //motor_forward();
    //delay(600);
    //turn_right_soft();
    //delay(1300);
    //motor_stop();
    //delay(1000);
    //motor_forward();
    //delay(400);
    //motor_stop();
    //delay(6000);

    //-----------------------Path 2,3----------------------
      // motor_forward();
      // delay(1200);
      // motor_stop();
      // delay(1000);
      // turn_right_soft();
     //  delay(2000);
     //  motor_stop();
     //  delay(1000);
     //  motor_forward();
     //  delay(1900);
    //   motor_stop();
    //   delay(1000);
     //  turn_left_soft();
    //   delay(1700);
    //   motor_stop();
    //   delay(1000);
    //   motor_forward();
    //   delay(2500);
    //   motor_stop();
    //   delay(1000);
    //   turn_left_soft();
    //   delay(1500);
   //    motor_stop();
   //    delay(1000);
  //     motor_forward();
   //    delay(1400);
    //   motor_stop();
    //   delay(1000);
     //  turn_right_soft();
       //delay(1750);
       //motor_forward();
       //delay(1700);
       //motor_stop();
       //delay(6000);
       //-------------Path 6, 7------------
       	   	  motor_forward();
              delay(1450);
              motor_stop();
              delay(1000);
              turn_right_soft();
              delay(3700);
              motor_stop();
              delay(1000);
              motor_forward();
              delay(1700);
              motor_stop();
              delay(1000);
              turn_right_soft();
              delay(1700);
              motor_stop();
              delay(1000);
              motor_forward();
              delay(2000);
              motor_stop();
              delay(1000);
              turn_right_soft();
              delay(1800);
              motor_stop();
              delay(1000);
              motor_forward();
              delay(1650);
              motor_stop();
              delay(1000);
              turn_right_soft();
              delay(3000);
              motor_stop();
              delay(1000);
              motor_forward();
              delay(800);
              motor_stop();
              delay(6000);

    PRINTF("Starting line-following from any zones...\n");

    while (1) {
        int left = read_line_sensor_left();
        int right = read_line_sensor_right();

        PRINTF("L: %d | R: %d\n", left, right);

        // Line following
        if (left < Left_THRESHOLD && right < Right_THRESHOLD) {
            motor_forward();
        } else if (left > Left_THRESHOLD && right <= Right_THRESHOLD) {
            turn_right_soft();
        } else if (right > Right_THRESHOLD && left <= Left_THRESHOLD) {
            turn_left_soft();
        } else {
            motor_stop();
        }

        // Color Zone Detection
        int zone = detect_color_id();  // <-- uses color sensor
        if (zone == 3) {  // GREEN
            green_zone_counter++;
            if (green_zone_counter > 20) {
                motor_stop();
                PRINTF("Reached GREEN (3) — Stopping robot\n");
                break;
            }
        } else if (zone == 1) {  // BLUE
            motor_stop();
            PRINTF("Reached BLUE (1) — Stopping robot\n");
            break;
        } else if (zone == 2) {  // YELLOW
            motor_stop();
            PRINTF("Reached YELLOW (2) — Stopping robot\n");
            break;
        } else if (zone == 4) {  // RED
            motor_stop();
            PRINTF("Reached RED (4) — Stopping robot\n");
            break;
        } else {
            green_zone_counter = 0;
        }

        delay(50);
    }

    return 0;
}
