#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "MKL46Z4.h" // Include MCU-specific header file

// Define encoder pulses per revolution for distance measurement
#define PULSES_PER_REV 400

// Motor Control Functions
// Initializes motor and sets up PWM and GPIO configurations
void motor_init(void);

// Moves the motor forward by activating the correct GPIO pins
void motor_forward(void);

// Stops the motor by disabling the motor control GPIO pins
void motor_stop(void);

// Adjusts motor speed by setting the PWM duty cycle
void motor_set_speed(int duty_cycle);

// PID Speed Control
// Sets the target speed for the motor (used in PID control)
void set_target_speed(float speed);

// Implements PID control for speed regulation across different surfaces
void pid_control(void);

// Encoder Functions
// Initializes the encoder hardware and configures interrupts
void encoder_init(void);

// Interrupt handler for encoder pulses (counts pulses for distance tracking)
void PORTA_IRQHandler(void);

// Checks if the robot has traveled the required distance
int distance_reached(void);

// Function to monitor encoder output and print real-time encoder values
void check_encoder_output(void);

// Timer Functions
// Initializes the Periodic Interrupt Timer (PIT) for delays
void pit_timer_init(void);

// Starts a timer with the given duration in milliseconds
void start_timer(int milliseconds);

// Checks if the timer has expired (returns 1 if expired, 0 otherwise)
int check_timer(void);

// Switch (SW1) Functions
// Initializes the SW1 push-button with an interrupt for user input
void init_sw1(void);

// Reads the state of SW1 (returns 1 if pressed, 0 if not)
int is_sw1_pressed(void);

// Interrupt handler for SW1 button press (handles user input events)
void PORTC_PORTD_IRQHandler(void);

#endif // MOTOR_CONTROL_H
