#include "motor_control.h"  // Include header file for function declarations
#include "fsl_debug_console.h" // Include debugging console for printing output

// Global variables for encoder and motor control
volatile int encoder_count = 0;  // Stores the encoder pulse count
volatile float target_speed = 500; // Target speed in RPM for motor
float kp = 3.0, ki = 0.8, kd = 0.2; // PID control parameters
float prev_error = 0, integral = 0; // Variables for PID calculation

// Global variables for timer and distance tracking
volatile int timer_expired = 0;  // Flag to check if timer has expired
volatile int distance_target = 1000; // Target encoder pulses for maintaining consistent distance
volatile int last_encoder_count = 0; // Stores last encoder count to monitor changes

/**
 * Initializes the motor control system, including PWM, GPIO, and switches.
 */
void motor_init(void) {
    // Enable clock for GPIO ports B, C, and A
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTA_MASK;
    SIM->SCGC6 |= SIM_SCGC6_TPM2_MASK; // Enable clock for TPM2 (PWM timer)

    // Configure PWM pins for motor control (PORTB2 & PORTB3)
    PORTB->PCR[2] = PORT_PCR_MUX(3); // Set MUX to alternative function (PWM)
    PORTB->PCR[3] = PORT_PCR_MUX(3); // Set MUX for PWM output

    // Configure motor direction control pins
    PORTB->PCR[0] = PORT_PCR_MUX(1); // Motor control pin
    PORTB->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[2] = PORT_PCR_MUX(1);

    // Set motor control pins as output
    GPIOB->PDDR |= (1 << 0) | (1 << 1);
    GPIOC->PDDR |= (1 << 1) | (1 << 2);

    // Initialize switch for user input
    init_sw1();

    // Initialize PWM timer
    TPM2->SC = TPM_SC_PS(5); // Set prescaler to divide clock
    TPM2->MOD = 24000 - 1; // Set PWM frequency
    TPM2->SC |= TPM_SC_CMOD(1); // Enable counter
    TPM2->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK; // Set PWM mode
    TPM2->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;

    PRINTF("Motor Initialized - PWM Ready\n"); // Debug message

    encoder_init(); // Initialize encoder system
    pit_timer_init(); // Initialize timer for delays
}

/**
 * Starts the motor forward.
 */
void motor_forward(void) {
    PRINTF("Moving Forward - PWM Enabled\n");
    GPIOB->PSOR = (1 << 1); // Set forward direction
    GPIOB->PCOR = (1 << 0);
    GPIOC->PSOR = (1 << 1);
    GPIOC->PCOR = (1 << 2);
    motor_set_speed(100); // Set default speed
}

/**
 * Sets the motor speed using PWM.
 */
void motor_set_speed(int duty_cycle) {
    if (duty_cycle < 50) duty_cycle = 50; // Ensure minimum speed
    if (duty_cycle > 100) duty_cycle = 100; // Limit maximum speed
    TPM2->CONTROLS[0].CnV = (duty_cycle * TPM2->MOD) / 100; // Set PWM duty cycle
    TPM2->CONTROLS[1].CnV = (duty_cycle * TPM2->MOD) / 100;
}

/**
 * Stops the motor.
 */
void motor_stop(void) {
    PRINTF("Stopping Motors\n");
    GPIOB->PCOR = (1 << 0) | (1 << 1); // Turn off motor
    GPIOC->PCOR = (1 << 1) | (1 << 2);
    motor_set_speed(0); // Set speed to 0
}

/**
 * PID Control for maintaining consistent speed.
 */
void pid_control(void) {
    float error = distance_target - encoder_count; // Calculate error
    integral += error; // Accumulate integral term
    float derivative = error - prev_error; // Calculate derivative term
    float output = (kp * error) + (ki * integral) + (kd * derivative); // PID equation
    prev_error = error; // Store previous error

    int duty_cycle = 50 + output; // Adjust motor speed
    motor_set_speed(duty_cycle);
}

/**
 * Initializes SW1 button with interrupt for user input.
 */
void init_sw1(void) {
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK | PORT_PCR_IRQC(0xA); // Configure as input with pull-up resistor
    GPIOC->PDDR &= ~(1 << 3); // Set as input
    NVIC_EnableIRQ(PORTC_PORTD_IRQn); // Enable interrupt
}

/**
 * Interrupt handler for SW1 button.
 */
void PORTC_PORTD_IRQHandler(void) {
    if (PORTC->ISFR & (1 << 3)) { // Check if SW1 interrupt triggered
        PRINTF("SW1 Interrupt Triggered\n");
        PORTC->ISFR |= (1 << 3); // Clear interrupt flag
    }
}

/**
 * Initializes the timer (PIT) for time-based operations.
 */
void pit_timer_init(void) {
    SIM->SCGC6 |= SIM_SCGC6_PIT_MASK; // Enable PIT clock
    PIT->MCR = 0x00; // Enable timer
    NVIC_EnableIRQ(PIT_IRQn); // Enable PIT interrupt
}

/**
 * Starts a timer for a given duration in milliseconds.
 */
void start_timer(int milliseconds) {
    timer_expired = 0; // Reset expiration flag
    PIT->CHANNEL[0].LDVAL = (milliseconds * 24000) - 1; // Load countdown value
    PIT->CHANNEL[0].TCTRL = 0x3; // Enable timer and interrupts
}

/**
 * Interrupt handler for PIT timer.
 */
void PIT_IRQHandler(void) {
    if (PIT->CHANNEL[0].TFLG & PIT_TFLG_TIF_MASK) { // Check if timer expired
        PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF_MASK; // Clear interrupt flag
        timer_expired = 1; // Set expiration flag
        PIT->CHANNEL[0].TCTRL = 0; // Disable timer
    }
}

/**
 * Checks if the timer has expired.
 */
int check_timer(void) {
    return timer_expired;
}

/**
 * Reads SW1 button state.
 */
int is_sw1_pressed(void) {
    return !(GPIOC->PDIR & (1 << 3)); // Return 0 if pressed, 1 if not
}

/**
 * Initializes the encoder system for measuring motor movement.
 */
void encoder_init(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK; // Enable clock for PORTA

    // Configure encoder input pins with interrupt
    PORTA->PCR[6] = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA);
    PORTA->PCR[7] = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA);
    PORTA->PCR[14] = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA);
    PORTA->PCR[15] = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0xA);

    GPIOA->PDDR &= ~((1 << 6) | (1 << 7) | (1 << 14) | (1 << 15)); // Set as input
    NVIC_EnableIRQ(PORTA_IRQn); // Enable encoder interrupts
    PRINTF("Encoder Initialized - Interrupts Ready\n");
}

/**
 * Interrupt handler for encoder updates.
 */
void PORTA_IRQHandler(void) {
    encoder_count++; // Increase encoder count
    PORTA->ISFR |= 0xFFFF; // Clear all encoder interrupt flags
    PRINTF("Encoder Count: %d\n", encoder_count);
}
void check_encoder_output(void) {
    if (encoder_count != last_encoder_count) {
        PRINTF("Current Encoder Count: %d\n", encoder_count);
        last_encoder_count = encoder_count;
    }
}

/**
 * Checks if the target distance is reached.
 */
int distance_reached(void) {
    return encoder_count >= distance_target;
}
