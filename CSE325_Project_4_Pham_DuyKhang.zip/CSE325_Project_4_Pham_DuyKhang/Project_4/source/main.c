#include "motor_control.h"    // Include the motor control header file
#include "board.h"            // Include board-specific configurations
#include "peripherals.h"      // Include peripheral initialization
#include "pin_mux.h"          // Include pin multiplexer settings
#include "clock_config.h"     // Include clock configuration settings
#include "fsl_debug_console.h" // Include debug console for printing messages

// Function to introduce a delay using the timer
void delay(int seconds) {
    start_timer(seconds * 1000);  // Start the timer for the given seconds converted to milliseconds
    while (!check_timer());       // Wait until the timer expires
}

int main(void) {
    // Initialize hardware components of the board
    BOARD_InitBootPins();        // Initialize the board's pins
    BOARD_InitBootClocks();      // Initialize the board's clocks
    BOARD_InitBootPeripherals(); // Initialize peripherals
    BOARD_InitDebugConsole();    // Initialize debug console for printing output

    motor_init(); // Initialize the motor control system
    PRINTF("System Ready. Press SW1 to Start\n"); // Display message on console

    while (1) {  // Infinite loop to continuously check for user input and control the motor
        check_encoder_output();  // Continuously monitor encoder values and display them

        if (is_sw1_pressed()) {  // Check if switch SW1 is pressed
            PRINTF("SW1 Pressed! Waiting for release...\n"); // Print message indicating button press
            while (is_sw1_pressed()); // Wait until the button is released

            PRINTF("SW1 Released! Moving in 2 seconds...\n"); // Notify about the delay before movement
            start_timer(2000); // Start a timer for 2 seconds
            while (!check_timer()); // Wait for the timer to expire

            motor_forward();  // Start moving the motor forward
            motor_set_speed(100); // Set motor speed to full speed (350 RPM)
            PRINTF("Moving forward for 6 seconds...\n"); // Notify about movement duration

            start_timer(6000); // Start a timer for 6 seconds
            while (!check_timer()); // Wait for the timer to expire before stopping

            motor_stop(); // Stop the motor
            PRINTF("Test Complete\n"); // Notify that the test is complete
        }
    }

    return 0; // Return 0 to indicate successful execution
}
