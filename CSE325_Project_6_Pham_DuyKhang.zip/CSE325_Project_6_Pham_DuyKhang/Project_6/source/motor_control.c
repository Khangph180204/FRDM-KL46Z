// motor_control.c
#include "motor_control.h"
#include "fsl_debug_console.h"

volatile int timer_expired = 0;

void motor_init(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK;
    SIM->SCGC6 |= SIM_SCGC6_TPM2_MASK;

    PORTB->PCR[0] = PORT_PCR_MUX(1); // Left backward
    PORTB->PCR[1] = PORT_PCR_MUX(1); // Left forward
    PORTC->PCR[1] = PORT_PCR_MUX(1); // Right forward
    PORTC->PCR[2] = PORT_PCR_MUX(1); // Right backward

    GPIOB->PDDR |= (1 << 0) | (1 << 1);
    GPIOC->PDDR |= (1 << 1) | (1 << 2);

    PORTB->PCR[2] = PORT_PCR_MUX(3); // TPM2_CH0 (PWM)
    PORTB->PCR[3] = PORT_PCR_MUX(3); // TPM2_CH1 (PWM)

    TPM2->MOD = 24000 - 1;
    TPM2->SC = TPM_SC_PS(5) | TPM_SC_CMOD(1);
    TPM2->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
    TPM2->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;

    pit_timer_init();
    init_sw1();
    init_sw2(); // SW2 initialization
}

void motor_forward(void) {
    GPIOB->PSOR = (1 << 1);
    GPIOB->PCOR = (1 << 0);
    GPIOC->PSOR = (1 << 1);
    GPIOC->PCOR = (1 << 2);
    motor_set_speed(100);
}

void motor_stop(void) {
    TPM2->CONTROLS[0].CnV = 0;
    TPM2->CONTROLS[1].CnV = 0;
    GPIOB->PCOR = (1 << 0) | (1 << 1);
    GPIOC->PCOR = (1 << 1) | (1 << 2);
}

void motor_set_speed(int duty) {
    if (duty < 0) duty = 0;
    if (duty > 100) duty = 100;
    TPM2->CONTROLS[0].CnV = (duty * TPM2->MOD) / 100;
    TPM2->CONTROLS[1].CnV = (duty * TPM2->MOD) / 100;
}

void pit_timer_init(void) {
    SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;
    PIT->MCR = 0;
    NVIC_EnableIRQ(PIT_IRQn);
}

void start_timer(int ms) {
    timer_expired = 0;
    PIT->CHANNEL[0].LDVAL = (ms * 24000) - 1;
    PIT->CHANNEL[0].TCTRL = PIT_TCTRL_TEN_MASK | PIT_TCTRL_TIE_MASK;
}

int check_timer(void) {
    return timer_expired;
}

void PIT_IRQHandler(void) {
    if (PIT->CHANNEL[0].TFLG & PIT_TFLG_TIF_MASK) {
        PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF_MASK;
        PIT->CHANNEL[0].TCTRL = 0;
        timer_expired = 1;
    }
}

//Switch Handling
void init_sw1(void) {
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    GPIOC->PDDR &= ~(1 << 3);
}

int is_sw1_pressed(void) {
    return !(GPIOC->PDIR & (1 << 3));
}

void init_sw2(void) {
    PORTC->PCR[12] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    GPIOC->PDDR &= ~(1 << 12);
}

int is_sw2_pressed(void) {
    return !(GPIOC->PDIR & (1 << 12));
}

// Line Sensor Functions
void init_line_sensor(void) {
    SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTE_MASK;
    PORTE->PCR[16] = PORT_PCR_MUX(0); // PTE16 = ADC0_SE1
    PORTE->PCR[17] = PORT_PCR_MUX(0); // PTE17 = ADC0_SE5a
    ADC0->SC1[0] = ADC_SC1_ADCH(31);
    ADC0->CFG1 = ADC_CFG1_ADIV(2) | ADC_CFG1_MODE(1);
}

int read_line_sensor_left(void) {
    ADC0->SC1[0] = 1;
    while (!(ADC0->SC1[0] & ADC_SC1_COCO_MASK));
    return ADC0->R[0];
}

int read_line_sensor_right(void) {
    ADC0->SC1[0] = 5;
    while (!(ADC0->SC1[0] & ADC_SC1_COCO_MASK));
    return ADC0->R[0];
}

// Soft Turn Adjustments
void turn_left_soft(void) {
    GPIOB->PCOR = (1 << 0);
    GPIOB->PCOR = (1 << 1);  // Stop left
    GPIOC->PSOR = (1 << 1);
    GPIOC->PCOR = (1 << 2);  // Right motor forward
    motor_set_speed(70);
}

void turn_right_soft(void) {
    GPIOB->PSOR = (1 << 1);
    GPIOB->PCOR = (1 << 0);  // Left motor forward
    GPIOC->PCOR = (1 << 1);
    GPIOC->PCOR = (1 << 2);  // Stop right
    motor_set_speed(70);
}

// Servo Control
void init_servo(void) {
    SIM->SCGC6 |= SIM_SCGC6_TPM1_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;
    PORTA->PCR[12] = PORT_PCR_MUX(3); // PTA12 = TPM1_CH0

    TPM1->MOD = 20000 - 1;
    TPM1->SC = TPM_SC_PS(3) | TPM_SC_CMOD(1);
    TPM1->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
    TPM1->CONTROLS[0].CnV = 9000;
}

void set_servo_angle(int angle) {
    int min = 3000;
    int max = 15000;
    int pulse = min + (angle * (max - min)) / 180;
    TPM1->CONTROLS[0].CnV = pulse;
}

void servo_center(void) { set_servo_angle(90); }
void servo_left(void)   { set_servo_angle(0);  }
void servo_right(void)  { set_servo_angle(180); }

// Ultrasonic Sensor
void init_ultrasonic(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTA_MASK;
    PORTD->PCR[2] = PORT_PCR_MUX(1); // PTD2: trigger
    GPIOD->PDDR |= (1 << 2);
    PORTA->PCR[13] = PORT_PCR_MUX(1); // PTA13: echo
    GPIOA->PDDR &= ~(1 << 13);
}

void trigger_pulse(void) {
    GPIOD->PSOR = (1 << 2);
    for (volatile int i = 0; i < 500; i++) __asm("nop");
    GPIOD->PCOR = (1 << 2);
}

int measure_distance_cm(void) {
    trigger_pulse();
    while (!(GPIOA->PDIR & (1 << 13)));
    int duration = 0;
    while (GPIOA->PDIR & (1 << 13)) {
        duration++;
        for (volatile int i = 0; i < 10; i++) __asm("nop");
    }

    int distance = (duration * 0.034 / 2);
    return (distance > 0 && distance < 400) ? distance : 0;
}
