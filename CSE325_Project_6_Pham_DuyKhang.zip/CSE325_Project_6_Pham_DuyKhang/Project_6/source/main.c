// main.c
#include "motor_control.h"
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"

#define Left_THRESHOLD 2000
#define Right_THRESHOLD 2000

void delay(int ms) {
    start_timer(ms);
    while (!check_timer());
}

int main(void) {
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();

    motor_init();
    init_line_sensor();
    init_servo();
    init_ultrasonic();
    init_sw1();

    servo_center();
    delay(500);

    PRINTF("Robot Ready. Press SW1 to start...\n");
    while (!is_sw1_pressed());  // Wait for start button
    delay(1000);

    PRINTF("Started: Line Following + Obstacle Avoidance\n");

    while (1) {
        int front = measure_distance_cm();

        //Obstacle Handlin
        if (front > 0 && front <= SAFE_DISTANCE_CM) {
            motor_stop();
            PRINTF("Obstacle detected (%d cm). Avoiding...\n", front);
            delay(300);

            // Scan Left
            servo_left(); delay(600);
            int right_distance = measure_distance_cm();
            PRINTF("Scan LEFT (actual RIGHT): %d cm\n", right_distance);

            // Scan Right
            servo_right(); delay(650);
            int left_distance = measure_distance_cm();
            PRINTF("Scan RIGHT (actual LEFT): %d cm\n", left_distance);

            // Reset Servo
            servo_center(); delay(400);

            if ((left_distance > SAFE_DISTANCE_CM && left_distance < 200) ||
                (right_distance > SAFE_DISTANCE_CM && right_distance < 200)) {

                PRINTF("Executing Rectangle Path\n");

                //if (right_distance >= left_distance) {
                    // Avoiding to the RIGHT
                    //turn_left_soft(); delay(1000);
                    //motor_forward(); delay(1000);
                    //turn_right_soft(); delay(1000);
                    //motor_forward(); delay(850);
                    //turn_right_soft(); delay(1000);
                    // motor_forward(); delay(800);
                if (right_distance >= left_distance) {
                  //Avoiding to the RIGHT
                  turn_left_soft(); delay(800);
                  motor_forward(); delay(800);
                  turn_right_soft(); delay(1500);
                  motor_forward(); delay(500);
                  turn_right_soft(); delay(1800);
                  motor_forward(); delay(600);
                  //turn_right_soft(); delay(800);
                  //motor_forward(); delay(300);
                } else {
                    // Avoiding to the LEFT
                    // turn_right_soft(); delay(1000);
                    // motor_forward(); delay(1000);
                    // turn_left_soft(); delay(1000);
                    // motor_forward(); delay(800);
                    // turn_left_soft(); delay(1000);
                    // motor_forward(); delay(800);
                }

                motor_stop();
                delay(300);
                PRINTF("Obstacle Avoided. Returning to Line.\n");
            } else {
                PRINTF("No path clear. Stopping.\n");
                motor_stop();
                delay(1000);
            }
            continue;
        }

        // Line Following Logic
        int left = read_line_sensor_left();
        int right = read_line_sensor_right();
        PRINTF("Line L:%d | R:%d\n", left, right);

        if (left < Left_THRESHOLD && right < Right_THRESHOLD) {
            motor_forward();
        } else if (left < Left_THRESHOLD && right > Right_THRESHOLD) {
            turn_right_soft();
        } else if (right < Right_THRESHOLD && left > Left_THRESHOLD) {
            turn_left_soft();
        } else {
            motor_stop();  // off track
        }

        delay(50);
    }

    return 0;
}
