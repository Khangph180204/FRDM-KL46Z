#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "fsl_port.h"

// Function prototypes
void TPM0_Init(void);  // Initializes TPM0 timer module
void TPM0_Delay_ms(uint32_t milliseconds);  // Generates delay using TPM0
void InitGPIO(void);  // Configures GPIO pins for LEDs
void InitSwitch(void);  // Configures reset switch (PTA1)
void LED_Toggle(GPIO_Type *gpio, uint32_t pin, uint32_t time_on, uint32_t time_off);  // Toggles LED
void displayMorse(char *message, int length);  // Displays Morse Code message

volatile int resetFlag = 0;  // Flag to indicate if reset button is pressed

// Morse Code Table (A-Z, 0-9) represented as strings
const char* morseTable[36] = {
    ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---",
    "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-",
    "..-", "...-", ".--", "-..-", "-.--", "--..",
    "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----."
};

// Initializes TPM0 (Timer/PWM Module 0) for timing control
void TPM0_Init(void) {
    SIM->SCGC6 |= SIM_SCGC6_TPM0_MASK;  // Enable TPM0 clock
    SIM->SOPT2 |= SIM_SOPT2_TPMSRC(1);  // Select TPM0 clock source
    TPM0->SC = 0;  // Disable TPM0 for configuration
    TPM0->MOD = 48000 - 1;  // Set MOD value for 1ms timing
    TPM0->SC = TPM_SC_PS(0) | TPM_SC_CMOD(1);  // Prescaler = 1, Enable TPM0
}

// Generates a delay in milliseconds using TPM0
void TPM0_Delay_ms(uint32_t milliseconds) {
    for (uint32_t i = 0; i < milliseconds; i++) {  // Loop through required milliseconds
        TPM0->CNT = 0;  // Reset counter
        while (!(TPM0->SC & TPM_SC_TOF_MASK));  // Wait for timer overflow
        TPM0->SC |= TPM_SC_TOF_MASK;  // Clear overflow flag
        if (resetFlag) return;  // Stop delay if reset button is pressed
    }
}

// Configures GPIO pins for the Red and Green LEDs
void InitGPIO(void) {
    SIM->SCGC5 |= (1 << 12) | (1 << 13);  // Enable clock for PORTD and PORTE
    PORTE->PCR[29] = PORT_PCR_MUX(1);  // Configure PTE29 as GPIO (Red LED)
    GPIOE->PDDR |= (1 << 29);  // Set PTE29 as output
    PORTD->PCR[5] = PORT_PCR_MUX(1);  // Configure PTD5 as GPIO (Green LED)
    GPIOD->PDDR |= (1 << 5);  // Set PTD5 as output
    GPIOE->PSOR = (1 << 29);  // Turn off Red LED
    GPIOD->PSOR = (1 << 5);  // Turn off Green LED
}

// Configures PTA1 as a reset button with an interrupt
void InitSwitch(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;  // Enable clock for PORTA
    PORTA->PCR[1] = PORT_PCR_MUX(1) | PORT_PCR_IRQC(10);  // Set PTA1 as GPIO with interrupt
    GPIOA->PDDR &= ~(1 << 1);  // Configure PTA1 as input
    NVIC_EnableIRQ(PORTA_IRQn);  // Enable interrupt in NVIC
}

// Interrupt handler for PTA1 (Reset button)
void PORTA_IRQHandler(void) {
    if (PORTA->ISFR & (1 << 1)) {  // Check if interrupt triggered
        resetFlag = 1;  // Set reset flag
        PORTA->ISFR |= (1 << 1);  // Clear interrupt flag
    }
}

// Toggles an LED for a given duration
void LED_Toggle(GPIO_Type *gpio, uint32_t pin, uint32_t time_on, uint32_t time_off) {
    gpio->PCOR = (1 << pin);  // Turn LED ON
    TPM0_Delay_ms(time_on);  // Wait for ON time
    gpio->PSOR = (1 << pin);  // Turn LED OFF
    TPM0_Delay_ms(time_off);  // Wait for OFF time
}

// Counts the number of words in the message
int countWords(char *message) {
    int count = 0;
    int inWord = 0;
    while (*message) {  // Loop through message
        if (*message == ' ') inWord = 0;  // Space detected
        else if (!inWord) { inWord = 1; count++; }  // New word detected
        message++;
    }
    return count;
}

// Displays Morse code for a single character
void displayMorseCharacter(char c, GPIO_Type *gpio, uint32_t pin) {
    if (resetFlag) return;  // Exit if reset button is pressed
    if (c >= 'a' && c <= 'z') c -= 32;  // Convert lowercase to uppercase
    const char* code = (c >= 'A' && c <= 'Z') ? morseTable[c - 'A'] :
                       (c >= '0' && c <= '9') ? morseTable[c - '0' + 26] : NULL;
    if (!code) return;
    for (int i = 0; code[i] != '\0'; i++) {  // Iterate through Morse Code
        if (resetFlag) return;
        LED_Toggle(gpio, pin, (code[i] == '.') ? 200 : 500, 250);  // Dot: 200ms, Dash: 500ms
    }
    TPM0_Delay_ms(600);  // Pause between characters
}

// Displays Morse code for an entire message
void displayMorse(char *message, int length) {
    int wordIndex = 1;
    int totalWords = countWords(message);
    GPIO_Type *currentLED;
    uint32_t currentPin;

    for (int i = 0; i < length; i++) {
        if (resetFlag) return;

        if (message[i] == ' ') {
            TPM0_Delay_ms(600);
            wordIndex++;
            continue;
        }

        // Assign LED based on word position
        if (wordIndex % 2 == 1) {
            currentLED = GPIOE;  // Red LED
            currentPin = 29;
        } else {
            currentLED = GPIOD;  // Green LED
            currentPin = 5;
        }

        displayMorseCharacter(message[i], currentLED, currentPin);
    }

    // Ensure final dot is displayed based on word count
    TPM0_Delay_ms(600);
    if (totalWords % 2 == 0) {
        LED_Toggle(GPIOE, 29, 200, 250);  // Red LED for even word count
    } else {
        LED_Toggle(GPIOD, 5, 200, 250);  // Green LED for odd word count
    }
}

// Main function: Calls displayMorse() once, then waits for reset
int main(void) {
    InitGPIO();
    TPM0_Init();
    InitSwitch();

    char message[] = "CSE 325";  // Default Morse Code message
    int length = sizeof(message) / sizeof(message[0]) - 1;

    while (1) {
        resetFlag = 0;
        displayMorse(message, length);
        while (!resetFlag);  // Wait for reset button
        TPM0_Delay_ms(500);  // Debounce delay
    }
}
