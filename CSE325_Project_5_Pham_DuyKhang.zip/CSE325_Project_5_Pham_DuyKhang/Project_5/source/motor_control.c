//motor_control.c
#include "motor_control.h"         // Header for declarations
#include "fsl_debug_console.h"     // For PRINTF debug output

volatile int timer_expired = 0;    // Flag for PIT-based delays

// Initialize motors, GPIO pins, and PWM channels
void motor_init(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK; // Enable PORTB and PORTC
    SIM->SCGC6 |= SIM_SCGC6_TPM2_MASK;                         // Enable TPM2 timer for PWM

    // Configure direction control pins as GPIO
    PORTB->PCR[0] = PORT_PCR_MUX(1);
    PORTB->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[1] = PORT_PCR_MUX(1);
    PORTC->PCR[2] = PORT_PCR_MUX(1);
    GPIOB->PDDR |= (1 << 0) | (1 << 1);  // Set PTB0, PTB1 as output
    GPIOC->PDDR |= (1 << 1) | (1 << 2);  // Set PTC1, PTC2 as output

    // Setup PTB2 and PTB3 for TPM2 PWM
    PORTB->PCR[2] = PORT_PCR_MUX(3);
    PORTB->PCR[3] = PORT_PCR_MUX(3);

    // Set PWM frequency
    TPM2->MOD = 24000 - 1;                         // Period value for ~1kHz PWM
    TPM2->SC = TPM_SC_PS(5) | TPM_SC_CMOD(1);      // Prescaler 32, start counter
    TPM2->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK; // Edge-aligned PWM
    TPM2->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;

    pit_timer_init();    // Initialize PIT for delays
    init_sw1();          // Initialize start switch
}

// Move robot forward
void motor_forward(void) {
    GPIOB->PSOR = (1 << 1);  // Left motor forward
    GPIOB->PCOR = (1 << 0);
    GPIOC->PSOR = (1 << 1);  // Right motor forward
    GPIOC->PCOR = (1 << 2);
    motor_set_speed(100);    // Full speed
}

// Stop both motors completely
void motor_stop(void) {
    TPM2->CONTROLS[0].CnV = 0;   // Stop PWM
    TPM2->CONTROLS[1].CnV = 0;
    GPIOB->PCOR = (1 << 0) | (1 << 1); // Clear motor pins
    GPIOC->PCOR = (1 << 1) | (1 << 2);
    motor_set_speed(0);
}

// Set PWM duty cycle based on percentage
void motor_set_speed(int duty) {
    if (duty < 0) duty = 0;
    if (duty > 100) duty = 100;
    TPM2->CONTROLS[0].CnV = (duty * TPM2->MOD) / 100;
    TPM2->CONTROLS[1].CnV = (duty * TPM2->MOD) / 100;
}

// Configure PIT timer
void pit_timer_init(void) {
    SIM->SCGC6 |= SIM_SCGC6_PIT_MASK; // Enable PIT clock
    PIT->MCR = 0;                     // Enable PIT module
    NVIC_EnableIRQ(PIT_IRQn);        // Enable interrupt
}

// Start PIT timer with ms delay
void start_timer(int ms) {
    timer_expired = 0;
    PIT->CHANNEL[0].LDVAL = (ms * 24000) - 1;
    PIT->CHANNEL[0].TCTRL = PIT_TCTRL_TEN_MASK | PIT_TCTRL_TIE_MASK;
}

// Return 1 if timer expired
int check_timer(void) {
    return timer_expired;
}

// PIT interrupt handler
void PIT_IRQHandler(void) {
    if (PIT->CHANNEL[0].TFLG & PIT_TFLG_TIF_MASK) {
        PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF_MASK;
        PIT->CHANNEL[0].TCTRL = 0;
        timer_expired = 1;
    }
}

// Configure PTC3 as input for pushbutton
void init_sw1(void) {
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; // Pull-up enabled
    GPIOC->PDDR &= ~(1 << 3); // Set as input
}

// Return 1 if button is pressed
int is_sw1_pressed(void) {
    return !(GPIOC->PDIR & (1 << 3));  // Active low
}

// Setup TPM1 PWM for servo motor (PTA12)
void init_servo(void) {
    SIM->SCGC6 |= SIM_SCGC6_TPM1_MASK;  // Enable TPM1
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK; // Enable PORTA

    PORTA->PCR[12] = PORT_PCR_MUX(3);   // PTA12 as TPM1 CH0

    TPM1->SC = 0;
    TPM1->MOD = 20000 - 1;              // 20 ms period for servo (50 Hz)
    TPM1->SC |= TPM_SC_PS(3);           // Prescaler 8
    TPM1->SC |= TPM_SC_CMOD(1);         // Start counter

    TPM1->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
    TPM1->CONTROLS[0].CnV = 9000;       // Default center pulse
}

// Convert angle (0-180) to PWM pulse width
void set_servo_angle(int angle) {
    int min = 3000;   // Min pulse (leftmost)
    int max = 15000;  // Max pulse (rightmost)
    int pulse = min + (angle * (max - min)) / 180;
    TPM1->CONTROLS[0].CnV = pulse;
}

// Helper macros to set servo angle
void servo_center(void) { set_servo_angle(90); }
void servo_left(void)   { set_servo_angle(0);  }
void servo_right(void)  { set_servo_angle(180); }

// Rotate robot 90° left in place
void turn_left_90(void) {
    motor_stop();
    delay(100);
    GPIOC->PSOR = (1 << 1);    // Right motor forward
    GPIOC->PCOR = (1 << 2);
    GPIOB->PCOR = (1 << 0);    // Left motor stop
    GPIOB->PCOR = (1 << 1);
    motor_set_speed(85);
    delay(870);                // Duration for approx 90°
    motor_stop();
    delay(300);
}

// Rotate robot 90° right in place
void turn_right_90(void) {
    motor_stop();
    delay(100);
    GPIOB->PSOR = (1 << 1);    // Left motor forward
    GPIOB->PCOR = (1 << 0);
    GPIOC->PCOR = (1 << 1);    // Right motor stop
    GPIOC->PCOR = (1 << 2);
    motor_set_speed(85);
    delay(870);
    motor_stop();
    delay(300);
}

// Perform U-turn (180°)
void u_turn(void) {
    GPIOB->PSOR = (1 << 1);    // Left motor forward
    GPIOB->PCOR = (1 << 0);
    GPIOC->PCOR = (1 << 1);    // Right motor reverse
    GPIOC->PSOR = (1 << 2);
    motor_set_speed(85);
    delay(1200);               // Rotate 180 degrees
    motor_stop();
    delay(300);
}

// Initialize HC-SR04 ultrasonic trigger (PTD2) and echo (PTA13)
void init_ultrasonic(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTA_MASK;
    PORTD->PCR[2] = PORT_PCR_MUX(1);     // PTD2 as GPIO output (trigger)
    GPIOD->PDDR |= (1 << 2);
    PORTA->PCR[13] = PORT_PCR_MUX(1);    // PTA13 as GPIO input (echo)
    GPIOA->PDDR &= ~(1 << 13);
}

// Send 10μs trigger pulse to HC-SR04
void trigger_pulse(void) {
    GPIOD->PSOR = (1 << 2);
    for (volatile int i = 0; i < 500; i++) __asm("nop");
    GPIOD->PCOR = (1 << 2);
}

// Measure time of echo pulse and convert to distance
int measure_distance_cm(void) {
    trigger_pulse();                               // Send pulse
    while (!(GPIOA->PDIR & (1 << 13)));            // Wait for echo to go high
    int duration = 0;
    while (GPIOA->PDIR & (1 << 13)) {              // Count duration while echo is high
        duration++;
        for (volatile int i = 0; i < 10; i++) __asm("nop");
    }

    int distance = (duration * 0.034 / 2);         // Convert to cm
    PRINTF("Echo duration: %d → Distance: %d cm\n", duration, distance);
    if (distance <= 0 || distance > 400) return 0; // Validate range
    return distance;
}
