//main.c
#include "motor_control.h"         // Custom header for motor and sensor control functions
#include "board.h"                 // Board-specific initialization
#include "peripherals.h"           // Peripheral initialization
#include "pin_mux.h"               // Pin configuration
#include "clock_config.h"          // Clock configuration
#include "fsl_debug_console.h"     // For debug output via PRINTF

// Delay function using PIT timer
void delay(int ms) {
    start_timer(ms);              // Start timer with specified ms
    while (!check_timer());       // Wait until timer expires
}

int main(void) {
    BOARD_InitBootPins();         // Initialize board pin muxing
    BOARD_InitBootClocks();       // Initialize system clocks
    BOARD_InitBootPeripherals();  // Initialize all peripherals
    BOARD_InitDebugConsole();     // Set up serial debug output

    motor_init();                 // Initialize motor GPIO and PWM
    init_servo();                 // Initialize servo PWM
    init_ultrasonic();            // Initialize ultrasonic sensor pins

    servo_center();               // Move servo to center (straight ahead)
    delay(500);                   // Wait 0.5s for stabilization

    PRINTF("System Ready. Waiting for SW1...\n"); // Notify user via serial

    while (!is_sw1_pressed());    // Wait for user to press start button
    delay(2000);                  // Wait 2 seconds before starting movement

    PRINTF("Started. Monitoring for obstacles...\n");

    while (1) {
        servo_center();           // Always start by facing forward
        delay(300);               // Give time for servo to settle

        int front = measure_distance_cm();  // Measure distance ahead
        PRINTF("Front: %d cm\n", front);    // Print distance to obstacle

        // If front is clear and within valid range
        if (front > SAFE_DISTANCE_CM && front < 200) {
            motor_forward();              // Move forward
            delay(1000);                  // Continue for 1 second
            motor_stop();                 // Stop after moving forward
        }
        // If obstacle is detected ahead
        else if (front > 0 && front <= SAFE_DISTANCE_CM) {
            motor_stop();                 // Stop the motors
            delay(300);                   // Brief pause

            // === Begin scanning for clear direction ===
            servo_left();                 // Rotate sensor to left
            delay(800);                   // Allow time to rotate
            int right = measure_distance_cm(); // LEFT scan reflects RIGHT side clearance
            PRINTF("[Actual RIGHT] Scanned LEFT: %d cm\n", right);

            servo_right();                // Rotate to right
            delay(800);                   // Wait for servo to stabilize
            int left = measure_distance_cm();  // RIGHT scan reflects LEFT side clearance
            PRINTF("[Actual LEFT] Scanned RIGHT: %d cm\n", left);

            servo_center();               // Return servo to center
            delay(500);                   // Pause before decision

            // === Decision logic based on scan ===
            if (right > SAFE_DISTANCE_CM && right >= left && right < 200) {
                PRINTF("Turning RIGHT (corrected direction).\n");
                turn_right_90();          // Turn robot to the right

                // Check if it's a side room
                servo_center();
                delay(300);
                int ahead = measure_distance_cm(); // Measure forward again

                if (ahead > SAFE_DISTANCE_CM && ahead < 200) {
                    motor_forward();      // Move into room
                    delay(1000);
                    motor_stop();
                    turn_left_90();       // Turn to exit side room
                    delay(300);
                    turn_left_90();       // Final turn to reorient forward
                    motor_forward();      // Move back to centerline
                    delay(1000);
                    motor_stop();
                }
                continue;                 // Skip rest of loop
            }
            else if (left > SAFE_DISTANCE_CM && left < 200) {
                PRINTF("Turning LEFT (corrected direction).\n");
                turn_left_90();           // Turn robot to the left

                // Check if it's a side room
                servo_center();
                delay(300);
                int ahead = measure_distance_cm();

                if (ahead > SAFE_DISTANCE_CM && ahead < 200) {
                    motor_forward();      // Move into room
                    delay(1000);
                    motor_stop();
                    turn_right_90();      // Turn to exit side room
                    delay(300);
                    turn_right_90();      // Final turn to face forward
                    motor_forward();      // Move back to centerline
                    delay(1000);
                    motor_stop();
                }
                continue;
            }
            else {
                PRINTF("Both sides blocked. Executing U-TURN...\n");
                u_turn();                 // Turn around completely
            }

            // Extra forward movement in narrow cases (e.g., T-junctions)
            motor_forward();
            delay(1000);
            motor_stop();
        }
        else {
            motor_stop();                 // If distance is invalid, stop
            PRINTF("Invalid or out-of-range sensor reading. Stopping.\n");
        }

        delay(200);                       // Short delay between each loop cycle
    }

    return 0;
}
