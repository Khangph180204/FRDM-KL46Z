#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "fsl_device_registers.h"

//Servo PWM Pulse Widths
#define SERVO_RIGHT   15000   // Pulse width to turn servo fully right (in TPM1->CnV)
#define SERVO_CENTER   9000   // Pulse width for center (neutral) position
#define SERVO_LEFT     3000   // Pulse width to turn servo fully left

#define SAFE_DISTANCE_CM 8    // Safe stopping distance in centimeters

//Motor Control
void motor_init(void);                 // Initialize GPIO, PWM channels for motor control
void motor_forward(void);             // Move both motors forward
void motor_stop(void);                // Stop both motors
void motor_set_speed(int duty);       // Set PWM duty cycle (0-100)

//Timer and Delay
void pit_timer_init(void);            // Initialize Periodic Interrupt Timer
void start_timer(int ms);             // Start PIT timer for 'ms' milliseconds
int check_timer(void);                // Return 1 when timer expires

//Start Switch
void init_sw1(void);                  // Configure PTC3 as input with pull-up resistor
int is_sw1_pressed(void);             // Check if SW1 button is pressed (active low)

//Servo Control
void init_servo(void);                // Setup TPM1 PWM for servo on PTA12
void set_servo_angle(int angle);      // Set angle in degrees (0-180) for servo
void servo_center(void);              // Center the servo (90°)
void servo_left(void);                // Rotate servo to left (0°)
void servo_right(void);               // Rotate servo to right (180°)

// Ultrasonic Sensor (HC-SR04)
void init_ultrasonic(void);           // Setup trigger (PTD2) and echo (PTA13) pins
int measure_distance_cm(void);        // Send pulse and return measured distance
void trigger_pulse(void);             // Generate 10μs trigger pulse

//Obstacle Avoidance Turn Functions
void turn_left_90(void);              // Perform 90° left rotation using motors
void turn_right_90(void);             // Perform 90° right rotation using motors
void u_turn(void);                    // Perform 180° U-turn when blocked

#endif
