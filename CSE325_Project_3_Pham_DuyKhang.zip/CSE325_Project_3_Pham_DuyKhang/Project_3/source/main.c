// main.c - Main control file for robot movement
#include "motor_control.h"   // Include motor control functions
#include "board.h"           // Include board configurations
#include "peripherals.h"     // Include peripheral settings
#include "pin_mux.h"         // Include pin configuration
#include "clock_config.h"    // Include clock settings
#include "fsl_debug_console.h" // Include debug console for printing messages

// Function to introduce a small delay to prevent switch bouncing
void debounce_delay() {
    for (volatile int i = 0; i < 300000; i++);  // Simple loop-based delay
}

int main(void) {
    // Initialize board peripherals, clock settings, and motor control
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
    motor_init();

    PRINTF("System Initialized. Waiting for switch press...\n");

    while (1) {
        // SW1 Pressed → Run "5" Shape (Sharp Turns with Stops)
        if (is_sw1_pressed()) {
            debounce_delay();  //Prevents multiple detections of switch press
            PRINTF("SW1 Pressed! Running '5' shape movement...\n");

            // Move forward before first turn
            motor_forward();
            start_timer(12);
            motor_stop();
            start_timer(5);  //Pause before turning

            // First left turn (sharp turn with 90 degree)
            motor_turn_left();
            motor_stop();
            start_timer(5);  //Pause before moving forward again

            // Move forward after first turn
            motor_forward();
            start_timer(12);
            motor_stop();
            start_timer(5);  //Pause before next turn

            // Second left turn (sharp turn with 90 degree)
            motor_turn_left();
            motor_stop();
            start_timer(5);  //Pause before moving forward again

            // Move forward after second turn
            motor_forward();
            start_timer(12);
            motor_stop();
            start_timer(5);  //Pause before next turn

            // First right turn (sharp turn with 90 degree)
            motor_turn_right();
            motor_stop();
            start_timer(5);  //Pause before moving forward again

            // Move forward after first right turn
            motor_forward();
            start_timer(12);
            motor_stop();
            start_timer(5);  //Pause before next turn

            // Second right turn (sharp turn with 90 degree)
            motor_turn_right();
            motor_stop();
            start_timer(5);  //Pause before moving forward again

            // Move forward after final turn
            motor_forward();
            start_timer(12);
            motor_stop();
            start_timer(5);  //Pause before stopping completely

            motor_stop();  //Final stop

            PRINTF("Robot completed '5' shape.\n");
        }

        // SW2 Pressed → Run "S" Shape (Smooth Turns, No Stops)
        if (is_sw2_pressed()) {
            debounce_delay();  // Prevents multiple detections of switch press
            PRINTF("SW2 Pressed! Running 'S' shape movement...\n");

            // Move forward before first turn
            motor_forward();
            start_timer(12);

            // First left turn (smooth)
            motor_smooth_turn_left();
            start_timer(5);  // Small delay to stabilize turn before moving

            // Move forward after first turn
            motor_forward();
            start_timer(12);

            // Second left turn (smooth)
            motor_smooth_turn_left();
            start_timer(5);  // Small delay to stabilize turn before moving

            // Move forward after second turn
            motor_forward();
            start_timer(12);

            // First right turn (smooth)
            motor_smooth_turn_right();
            start_timer(4);  // Small delay to stabilize turn before moving

            // Move forward after first right turn
            motor_forward();
            start_timer(12);

            // Second right turn (smooth)
            motor_smooth_turn_right();
            start_timer(4);  // Small delay to stabilize turn before moving

            // Move forward after final turn
            motor_forward();
            start_timer(12);
            motor_stop();  // Final stop

            PRINTF("Robot completed 'S' shape.\n");
        }
    }
    return 0;
}
