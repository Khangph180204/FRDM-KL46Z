#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "MKL46Z4.h"  // Include the microcontroller header for hardware access

// Function to initialize motor control, GPIO, and timers
void motor_init(void);

// Function to set motor speed (PWM duty cycle: 50% - 100%)
void motor_set_speed(int duty_cycle);

// Function to move the robot forward
void motor_forward(void);

// Function to turn the robot LEFT (sharp turn for "5" shape - SW1)
void motor_turn_left(void);

// Function to turn the robot RIGHT (sharp turn for "5" shape - SW1)
void motor_turn_right(void);

// Function to stop both motors
void motor_stop(void);

// Function to start a delay timer (blocking function)
void start_timer(int seconds);

// Function to check if the timer has expired
int check_timer(void);

// Function to check if SW1 (PTC3) is pressed (Triggers "5" shape movement)
int is_sw1_pressed(void);

// Function to check if SW2 (PTC12) is pressed (Triggers "S" shape movement)
int is_sw2_pressed(void);

#endif // MOTOR_CONTROL_H
