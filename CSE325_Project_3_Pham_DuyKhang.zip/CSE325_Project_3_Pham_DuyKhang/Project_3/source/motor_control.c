// Include the motor control header file
#include "motor_control.h"

// Global variable to track timer expiration
volatile int timer_expired = 0;

// Function to initialize the motor system
void motor_init(void) {
    // Enable clock for PORTB and PORTC (Motor & Switches)
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK;
    SIM->SCGC6 |= SIM_SCGC6_TPM2_MASK; // Enable TPM2 clock (PWM timer for motor speed control)

    // Configure PWM pins for motor speed control
    PORTB->PCR[2] = PORT_PCR_MUX(3); // PTB2 as TPM2_CH0 (PWM A)
    PORTB->PCR[3] = PORT_PCR_MUX(3); // PTB3 as TPM2_CH1 (PWM B)

    // Configure motor control GPIO pins
    PORTB->PCR[0] = PORT_PCR_MUX(1); // AI2 (Left Motor)
    PORTB->PCR[1] = PORT_PCR_MUX(1); // AI1 (Left Motor)
    PORTC->PCR[1] = PORT_PCR_MUX(1); // BI1 (Right Motor)
    PORTC->PCR[2] = PORT_PCR_MUX(1); // BI2 (Right Motor)

    // Configure switches as input with pull-up resistors
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;  // SW1 (PTC3)
    PORTC->PCR[12] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; // SW2 (PTC12)

    // Set switches as input
    GPIOC->PDDR &= ~((1 << 3) | (1 << 12));

    // Set motor control pins as output
    GPIOB->PDDR |= (1 << 0) | (1 << 1);
    GPIOC->PDDR |= (1 << 1) | (1 << 2);

    // Configure TPM2 for PWM (Pulse Width Modulation) speed control
    TPM2->SC = TPM_SC_PS(7); // Set the prescaler
    TPM2->MOD = 48000 - 1; // Set PWM period
    TPM2->SC |= TPM_SC_CMOD(1); // Enable PWM timer

    // Configure TPM2 channels for PWM output
    TPM2->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
    TPM2->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;

    // Set motor speed to zero initially
    motor_set_speed(0);
}

// Function to set motor speed (PWM duty cycle)
void motor_set_speed(int duty_cycle) {
    if (duty_cycle < 50) duty_cycle = 50;  // Ensure minimum speed
    if (duty_cycle > 100) duty_cycle = 100; // Cap maximum speed
    TPM2->CONTROLS[0].CnV = (duty_cycle * TPM2->MOD) / 100;
    TPM2->CONTROLS[1].CnV = (duty_cycle * TPM2->MOD) / 100;
}

// Function to move both motors forward
void motor_forward(void) {
    GPIOB->PSOR = (1 << 1); // AI1 HIGH (Left Motor Forward)
    GPIOB->PCOR = (1 << 0); // AI2 LOW
    GPIOC->PSOR = (1 << 1); // BI1 HIGH (Right Motor Forward)
    GPIOC->PCOR = (1 << 2); // BI2 LOW
    motor_set_speed(100); // Set speed to 100%
}

// SHARP TURN LEFT with 90 degree (Used for "5" shape movement - SW1)
void motor_turn_left(void) {
    motor_stop(); // Stop motors before turning
    start_timer(5); // Short delay before turning
    GPIOB->PCOR = (1 << 1) | (1 << 0); // Left motor stops
    GPIOC->PSOR = (1 << 1); // Right motor moves forward
    GPIOC->PCOR = (1 << 2);
    motor_set_speed(85); // Set turning speed
    start_timer(14); // Duration for turn
    motor_stop();
    start_timer(5); // Pause after turn
}

// SHARP TURN RIGHT with 90 degree (Used for "5" shape movement - SW1)
void motor_turn_right(void) {
    motor_stop(); // Stop motors before turning
    start_timer(5); // Short delay before turning
    GPIOC->PCOR = (1 << 1) | (1 << 2); // Right motor stops
    GPIOB->PSOR = (1 << 1); // Left motor moves forward
    GPIOB->PCOR = (1 << 0);
    motor_set_speed(85); // Set turning speed
    start_timer(17); // Duration for turn
    motor_stop();
    start_timer(5); // Pause after turn
}

//SMOOTH TURN LEFT (Used for "S" shape movement - SW2)
void motor_smooth_turn_left(void) {
    motor_set_speed(85); // Set turning speed
    GPIOB->PCOR = (1 << 1); // Left motor moves backward
    GPIOB->PSOR = (1 << 0);
    GPIOC->PSOR = (1 << 1); // Right motor moves forward
    GPIOC->PCOR = (1 << 2);
    start_timer(2); // Shorter duration for smooth turn
}

//SMOOTH TURN RIGHT (Used for "S" shape movement - SW2)
void motor_smooth_turn_right(void) {
    motor_set_speed(85); // Set turning speed
    GPIOB->PSOR = (1 << 1); // Left motor moves forward
    GPIOB->PCOR = (1 << 0);
    GPIOC->PCOR = (1 << 1); // Right motor moves backward
    GPIOC->PSOR = (1 << 2);
    start_timer(5); // Shorter duration for smooth turn
}

// Function to stop both motors
void motor_stop(void) {
    GPIOB->PCOR = (1 << 0) | (1 << 1); // Stop left motor
    GPIOC->PCOR = (1 << 1) | (1 << 2); // Stop right motor
    motor_set_speed(5); // Set minimal speed to prevent jerking
}

// Function to create a delay (blocking timer)
void start_timer(int seconds) {
    TPM2->CNT = 0;
    timer_expired = 0;
    int counter = 0;

    while (counter < seconds) {
        while (!(TPM2->SC & TPM_SC_TOF_MASK)); // Wait for timer overflow event
        TPM2->SC |= TPM_SC_TOF_MASK; // Clear timer overflow flag
        counter++;
    }

    timer_expired = 1; // Mark timer as expired
}

// Function to check if the timer has expired
int check_timer(void) {
    return timer_expired;
}

// Function to check if SW1 (PTC3) is pressed
int is_sw1_pressed(void) {
    return !(GPIOC->PDIR & (1 << 3)); // Return true if switch is pressed
}

// Function to check if SW2 (PTC12) is pressed
int is_sw2_pressed(void) {
    return !(GPIOC->PDIR & (1 << 12)); // Return true if switch is pressed
}
